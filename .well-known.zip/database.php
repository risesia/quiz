<?php
$url='http://localhost/equiza/S0FU;8RRH}G&';
$hostName = "localhost";
$dbUser = "asqalla1_admin";
$dbPassword = "Qrk7sKKblFbY";
$dbName = "asqalla1_finn_db";
$conn = mysqli_connect($hostName, $dbUser, $dbPassword, $dbName);
if ($conn -> connect_errno) {
  echo "Failed to connect to MySQL: " . $conn -> connect_error;
  exit();
}

?>